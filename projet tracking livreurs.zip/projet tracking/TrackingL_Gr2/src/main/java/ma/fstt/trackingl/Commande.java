package ma.fstt.trackingl;

import javafx.fxml.FXML;

public class Commande extends Client {
    @FXML
    private Long id_commande;
    @FXML
     private String date_debut;
    @FXML
     private String date_fin;
    @FXML
    private Long nbr_km;
    @FXML
    private String etat;

    public Commande(long id_commande, String date_debut,String date_fin,long nbr_km,String etat) {
        this.id_commande=id_commande;
        this.date_debut=date_debut;
        this.date_fin=date_fin;
        this.nbr_km=nbr_km;
        this.etat=etat;
    }

    public Commande(String text, String text1, String text2, String id, String text3) {
    }

    public Commande(String text, String text1, String text2) {
        super(text, text1, text2);
    }


    public long getId() {

        return id_commande;
    }

    public String getDate_debut() {
        return date_debut;
    }
    public String getDate_fin(){
        return date_fin;
    }
    public String getEtat(){
        return etat;
    }
    public long getNbr_km(){
        return nbr_km;
    }
    @Override
    public String toString() {
        return "Livreur{" +
                "id_commande=" + id_commande +
                ", date_debut='" + date_debut + '\'' +
                ", date_fin='" + date_fin + '\'' +
                ",nbr_km+'"+nbr_km+'\''+
                ",etat+'"+etat+'\''+
                '}';
    }
}
