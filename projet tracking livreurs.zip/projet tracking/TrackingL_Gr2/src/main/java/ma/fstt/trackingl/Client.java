package ma.fstt.trackingl;

public class Client {
    public Client(String text, String text1, String text2) {
    }

    public Client() {
    }
}
