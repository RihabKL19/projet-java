package ma.fstt.trackingl;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import ma.fstt.model.Livreur;
import ma.fstt.model.LivreurDAO;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class CommandeController implements Initializable {
    @FXML
    private TextField id_commande ;
    @FXML
    private TextField date_debut ;
    @FXML
    private TextField date_fin ;
    @FXML
    private TextField nbr_km ;

    @FXML
    private TextField etat ;
    @FXML
    private TableView<Commande> mytable ;

    @FXML
    private TableColumn<Commande , Integer> col_idcommande ;

    @FXML
    private TableColumn <Commande ,String > col_datedebut ;

    @FXML
    private TableColumn <Commande ,String> col_datefin ;


    @FXML
    private TableColumn <Commande ,Integer> col_nbrkm ;


    @FXML
    private TableColumn <Commande ,String> col_etat ;

    public CommandeController(TextField id_commande) throws SQLException {
        this.id_commande = id_commande;
    }


    @FXML
    protected void onSaveButtonClick() {

        // accees a la bdd

        try {
           CommandeDAO commandeDAO = new CommandeDAO();

           Commande com = new Commande(id_commande.getText(),date_debut.getText(), date_fin.getText() ,nbr_km.getId() ,etat.getText());
            commandeDAO.save(com);
            UpdateTable();
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }


    public void UpdateTable(){
        TableColumn col_id;
        id_commande.getCharacters();
        date_debut.getCharacters();
        date_fin.getCharacters();
        nbr_km.getCharacters();
        etat.getCharacters();
        mytable.setItems(this.getDataCommande());
    }

    private ObservableList<Commande> getDataCommande() {
        return null;
    }

    public static ObservableList<Commande> getDataLivreurs(){

        CommandeDAO CommandeDAO = null;

        ObservableList<Commande> listfx = FXCollections.observableArrayList();

        try {
            CommandeDAO = new CommandeDAO();
            for (Commande ett : CommandeDAO.getAll())
                listfx.add(ett);

        }catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return listfx ;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        UpdateTable();

    }
}