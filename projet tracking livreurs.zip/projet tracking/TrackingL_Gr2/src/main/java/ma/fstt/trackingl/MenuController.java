package ma.fstt.trackingl;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.scene.image.Image;
import javafx.fxml.FXML;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.Statement;
import java.util.ResourceBundle;


public class MenuController {

        public MenuController() {

        }

        @FXML
        private Button clientButton;
        @FXML
        private Button commandeButton;
        @FXML
        private Button livreurButton;
        @FXML
        private Button produitButton;


        public void setClientButton() throws IOException {
                Main m = new Main();
                m.changeScene("client.fxml");
        }
        public void setCommandeButton() throws IOException {
                Main m = new Main();
                m.changeScene("commande.fxml");
        }

        public void setProduitButton() throws IOException {
                Main m = new Main();
                m.changeScene("produit.fxml");
        }

        public void setLivreurButton() throws IOException {
                Main m = new Main();
                m.changeScene("hello-view.fxml");

        }
}


