package ma.fstt.trackingl;

public class ClientDAO {
    public ClientDAO(String text, String text1, String text2) {
    }

    public ClientDAO() {

    }

    public void save(ClientDAO com) {
    }
}
