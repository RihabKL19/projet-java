package ma.fstt.trackingl;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.scene.input.MouseEvent;

import java.io.IOException;

public class RegisterController {
    public  RegisterController() {

    }
    @FXML
    public Button register_bttn;


    public void Userlogin() throws IOException  {
        Main m = new Main();
        m.changeScene("login.fxml");

    }
}
