package ma.fstt.trackingl;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class ClientController implements Initializable {
    @FXML
    private TextField id_client ;

    @FXML
    private TextField username ;

    @FXML
    private TextField password ;
    @FXML
    private TableView<Client> mytable ;

    @FXML
    private TableColumn<Client , Integer> col_idclient ;

    @FXML
    private TableColumn <Client ,String > col_username;

    @FXML
    private TableColumn <Commande ,String> col_password ;



    public ClientController(TextField id_client) throws SQLException {
        this.id_client = id_client;
    }


    @FXML
    protected void onSaveButtonClick() {

        // accees a la bdd

        ClientDAO clientDAO = new ClientDAO();

        ClientDAO com = new ClientDAO(id_client.getText(),username.getText(), password.getText());
        clientDAO.save(com);
        UpdateTable();
    }


    public void UpdateTable(){
        TableColumn col_id;
        id_client.getCharacters();
        username.getCharacters();
        password.getCharacters();

        mytable.setItems(this.getDataClient());
    }

    private ObservableList<Client> getDataClient() {
        return null;
    }




    public static ObservableList<Client> getDataLivreurs(){

        ClientDAO ClientDAO = null;

        ObservableList<Client> listfx = FXCollections.observableArrayList();

        try {
            ClientDAO = new ClientDAO();
            for (Client ett : CommandeDAO.getAll())
                listfx.add(ett);

        }catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return listfx ;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        UpdateTable();

    }
}